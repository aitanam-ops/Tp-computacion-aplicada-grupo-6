#!/bin/bash

# Función de ayuda
mostrar_ayuda() {
    cat << EOH
Uso: $0 <directorio_origen> <directorio_destino>
     $0 -help

Descripción:
  Genera un respaldo comprimido (.tar.gz) del directorio de origen indicado
  dentro del directorio de destino, agregando la fecha en formato ANSI (YYYYMMDD).
  Ejemplo: para /var/log genera <destino>/log_bkp_20240302.tar.gz

Argumentos:
  directorio_origen   Ruta del directorio a respaldar (ej. /var/log o /www_dir)
  directorio_destino  Ruta donde se guardará el archivo (ej. /backup_dir)
  -help               Muestra este mensaje de ayuda y finaliza

Ejemplos:
  $0 /var/log /backup_dir
  $0 /www_dir /backup_dir
EOH
}

# Verificar solicitud de ayuda
if [[ "$1" == "-help" || "$1" == "--help" || "$1" == "-h" ]]; then
    mostrar_ayuda
    exit 0
fi

# Validar cantidad de argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren exactamente 2 argumentos (origen y destino)." >&2
    echo "Ejecute '$0 -help' para ver las instrucciones de uso." >&2
    exit 1
fi

ORIGEN="${1%/}"
DESTINO="${2%/}"

# Caso especial si alguien pasara "/"
[[ -z "$ORIGEN" ]] && ORIGEN="/"
[[ -z "$DESTINO" ]] && DESTINO="/"

# Validar existencia y disponibilidad del sistema de archivos de origen
if [[ ! -d "$ORIGEN" || ! -r "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no es accesible." >&2
    exit 2
fi

if ! df -P "$ORIGEN" >/dev/null 2>&1; then
    echo "Error: El sistema de archivos de origen '$ORIGEN' no está disponible." >&2
    exit 2
fi

# Validar existencia, permisos y disponibilidad del sistema de archivos de destino
if [[ ! -d "$DESTINO" || ! -w "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no tiene permisos de escritura." >&2
    exit 3
fi

if ! df -P "$DESTINO" >/dev/null 2>&1; then
    echo "Error: El sistema de archivos de destino '$DESTINO' no está disponible." >&2
    exit 3
fi

# Verificar si el destino es un punto de montaje definido en /etc/fstab y si está montado
if grep -qsE "^[^#]+[[:space:]]+${DESTINO}[[:space:]]" /etc/fstab; then
    if ! mountpoint -q "$DESTINO"; then
        echo "Error: El destino '$DESTINO' está en /etc/fstab pero la partición no se encuentra montada." >&2
        exit 3
    fi
fi

# Construir nombre del archivo con formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO_BKP="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

# Ejecutar el respaldo comprimido
tar -czf "$ARCHIVO_BKP" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

if [[ $? -eq 0 ]]; then
    echo "Backup completado exitosamente: $ARCHIVO_BKP"
    exit 0
else
    echo "Error: Falló la creación del archivo de respaldo '$ARCHIVO_BKP'." >&2
    exit 4
fi
