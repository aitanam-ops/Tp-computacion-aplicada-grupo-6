history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
vim /etc/hostname 
nano /etc/hostname 
pico /etc/hostname 
vim /etc/hostname 
vim /etc/hosts
reboot
vim /etc/apt
vim /etc/apt/sources.list
apt update
ls -la /etc/apt/sources.list.d/
vim /etc/apt/sources.list
apt update
pin -c 3 8.8.8.8
ping -c 3 8.8.8.8
vim /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs
reboot 
apt update
systemctl status ssh
/usr/sbin/sshd -t
clear 
/usr/sbin/sshd -t
nano /etc/ssh/sshd_config
/usr/sbin/sshd -t
mkdir -p /run/sshd
chmod 0755 /run/sshd
/usr/sbin/sshd -t
echo "d /run/sshd 0755 root root -" > /etc/tmpfiles.d/sshd.conf
system-tmpfiles --create /etc/tmpfiles.d/sshd.conf
systemd-tmpfiles --create /etc/tmpfiles.d/sshd.conf
systemctl status ssh
systemctl reset-failed ssh
systemctl restart ssh
systemctl status ssh
nano /root/.ssh/authorized_keys 
clear
apt update
apt upgrade -y
reboot
apt install -y build-essential dkms linux-headers-
apt install -y build-essential dkms linux-headers-$(uname -r)
apt autoremove
reboot
apt install -y build-essential dkms linux-headers-$(uname -r)
mount /dev/cdrom /mnt
lsblk
lsblk
lsblk
mount /dev/sr0 /mnt
ls /mnt
cd /media/
ls
ls -la
ce
cd ..
systemctl enable --now ssh
mkdir -p ~/.ssh
chmod 700 ~/.ssh 
echo ¨ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDom0gO3Rr2B2IUlyp3HgGMohZzNFfXxgugYcUrpXjcCQHEJ/xZvmY05MZFF5cN3fXTDYadWNDtIC3IpCHYD9dS3RCVrjztayH5CsdE5oBImrVea85bYspZfKlNZ/328r4uQh/8+LcpqpGDvTlj2f8GnnPhABQq5lwoVZ04D9ZOsbwBQM3wVg9POMZo8WXjtPpYvVxfQb6RZNBZoY17EUF73rWlm63Qz6kI5tq6yMyZyaqZGr7G4x+yAV7N/YWxqmNz+fE4Awv3QNyH6xhKIkRTnajEW68aeQuFX+oY0KBSDhyvYeUZvki2s7jVWNXxMu07xYQv7G7VKL14N9Tl3t0i11tsalhyWxBspyzSQmjgQCrOxvCgNUbsaP5/wHATty64QQHLL+roPHxtds/nJcnwHO5fGm3E6iIG4t3ODUrWfd+FkLmlEhzk8+cm8U1G9x58u/NXH4hI264nWR0k6lrnAfSWzlP38B39uFgrjLqzljA8HmAUOBxYLIHmU6nnfTk= sonda@ttys9-HP-ENVY-Notebook¨ >>  ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys 
cat ~/.ssh/authorized_keys
exit
apt update
apt upgrade -y
apt install -y apache2
systemctl enable --now apache2
clear
apt install -y mariadb-server mariadb-client
systemctl enable --now mariadb
mariabd --version
mariadb --version
clear
apt install -y php libapache2-mod-php php-mysql php-cli php-curl php-gd php-mbstring php-xml php-zip
php -b
clear
php -v
ls -la
echo "<?php phpinfo(); ?>" > /var/www/html/info.php
mkdir -p material_adicional
tar -xvf Material_Adicional_TPVMCA.tar.gz -C material_adicional/
clear
ls -la
cd material_adicional/
ls -la
mv Material_Adicional_TPVMCA /home/root
cd..
cd ..
ls -la
cd /home/root
ls -la
cd ..
ls -la
cd
pwd
ls -la
rm material_adicional/
rm material_adicional
mrdir material_adicional
rmdir material_adicional
ls -la
tar -xvf Material_Adicional_TPVMCA.tar.gz -C /root
ls -la
cd Material_Adicional_TPVMCA/
clear
ls
cp index.php /var/www/html
cp logo.png /var/www/html
chown -R www-data:www-data /var/www/html/
chmod -R 755 /var/www/html/
sed -i 's/DirectoryIndex index.html index.cgi index.pl index.php/DirectoryIndex index.php index.html index.cgi index.pl/' /etc/apache2/mods-enabled/dir.conf
systemctl reload apache2
find /root -name "db.sql"
mariadb -u root -p -e "
CREATE DATABASE IF NOT EXISTS ingenieria CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'lcars'@'localhost' IDENTIFIED BY 'NCC1701D';
GRANT ALL PRIVILEGES ON ingenieria.* TO 'lcars'@'localhost';
FLUSH PRIVILEGES;"
mariadb -u lcars -pNCC1701D ingenieria < /root/Material_Adicional_TPVMCA/db.sql
mariadb -u root -p -e "
DROP DATABASE IF EXISTS ingenieria;
DROP USER IF EXISTS 'lcars'@'localhost';
DROP USER IF EXISTS 'lcars'@'%';
FLUSH PRIVILEGES;"
mariadb -u root -p -e "
DROP DATABASE IF EXISTS ingenieria;
DROP USER IF EXISTS 'lcars'@'localhost';
DROP USER IF EXISTS 'lcars'@'%';
mariadb -u root -p -e "
DROP DATABASE IF EXISTS ingenieria;
DROP USER IF EXISTS 'lcars'@'localhost';
DROP USER IF EXISTS 'lcars'@'%';
FLUSH PRIVILEGES;"
mariadb -u root -p < /root/Material_Adicional_TPVMCA/db.sql
mariadb -u lcars -pNCC1701D ingenieria -e "SELECT * FROM alumnos;"
cd
clear
ls -la
ls -la Material_Adicional_TPVMCA
clear
ip -br a
cp /etc/network/interfaces /etc/network/interfaces.bak
cat << 'EOF' > /etc/network/interfaces
source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

allow-hotplug enp0s3
iface enp0s3 inet static
    address 192.168.1.200
    netmask 255.255.255.0
    gateway 192.168.1.1
    dns-nameservers 8.8.8.8 1.1.1.1
EOF

systemctl restart networking
ip -4 a
sed -i 
sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
systemctl restart ssh
sshd -T | grep PermitRootLogin
sshd -T | grep permitrootlogin
ip -4
